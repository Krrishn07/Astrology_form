from flask import Flask, render_template, request, redirect
import sqlite3

app = Flask(__name__)

def create_table():
    conn = sqlite3.connect('astrology.db')
    c = conn.cursor()
    c.execute('''
        CREATE TABLE IF NOT EXISTS astrology_form (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT,
            dob DATE,
            tob TIME,
            pob TEXT,
            email TEXT,
            phone TEXT
        )
    ''')
    conn.commit()
    conn.close()

create_table()

@app.route('/')
def form():
    return render_template('astro_form.html')

@app.route('/submit', methods=['POST'])
def submit_form():
    name = request.form ['name']
    dob = request.form ['dob']
    tob = request.form ['tob']
    pob = request.form ['pob']
    email = request.form['email']
    phone = request.form['phone']
    
    conn = sqlite3.connect('astrology.db')
    c = conn.cursor()
    c.execute('''
        INSERT INTO astrology_form (name, dob, tob, pob, email, phone)
        VALUES (?, ?, ?, ?, ?, ?)
    ''', (name, dob, tob, pob, email, phone))
    conn.commit()
    conn.close()

    return redirect('/view')

@app.route('/view')
def view_data():
     conn = sqlite3.connect('astrology.db')
     c = conn.cursor()
     c.execute('SELECT * FROM astrology_form')
     data = c.fetchall()
     conn.close()
     return render_template('view.html', data=data)

@app.route('/delete/<int:id>', methods=['GET'])
def delete_submission(id):
    conn = sqlite3.connect('astrology.db')
    c = conn.cursor()
    c.execute("DELETE FROM astrology_form WHERE id = ?", (id,))
    conn.commit()
    conn.close()
    return redirect('/view')

if __name__ == '__main__':
    app.run(debug=True)

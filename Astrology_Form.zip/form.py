from flask import Flask, render_template, request, redirect
import sqlite3

app = Flask(__name__)

# Create the database and table (if not exists)
def create_table():
    conn = sqlite3.connect('astrology.db')
    c = conn.cursor()
    c.execute('''
        CREATE TABLE IF NOT EXISTS astrology_form (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            janam_tithi DATE,
            janam_samay TIME,
            janam_sthan TEXT,
            vikrami_samvant INTEGER,
            shak INTEGER,
            reetu TEXT,
            maas TEXT,
            paksha TEXT, 
            vaar TEXT,
            tithi TEXT,
            nakshatra TEXT,
            vansh TEXT,
            gotra TEXT,
            prapitamah TEXT,
            pitamah TEXT,
            pita TEXT,
            mata TEXT,
            santaan TEXT,
            lagna TEXT,
            janam_nakshatra TEXT,
            charana TEXT,
            janam_namakshar TEXT,
            janam_naam TEXT,
            rashi TEXT,
            swami TEXT,
            varna TEXT,
            vashya TEXT,
            yoni TEXT,
            gana TEXT,
            nadi TEXT,
            paya TEXT
        )
    ''')
    conn.commit()
    conn.close()

create_table()

# Route to show the form
@app.route('/')
def form():
    return render_template('astro_form.html')

# Route to handle form submission
@app.route('/submit', methods=['POST'])
def submit_form():
    janam_tithi = request.form['janam_tithi']
    janam_samay = request.form['janam_samay']
    janam_sthan = request.form['janam_sthan']
    vikrami_samvant = request.form['vikrami_samvant']
    shak = request.form['shak']
    reetu = request.form['reetu']
    maas = request.form['maas']
    paksha = request.form['paksha']
    vaar = request.form['vaar']
    tithi = request.form['tithi']
    nakshatra = request.form['nakshatra']
    vansh = request.form['vansh']
    gotra = request.form['gotra']
    prapitamah = request.form['prapitamah']
    pitamah = request.form['pitamah']
    pitamah = request.form['pitamah']
    pita = request.form['pita']
    mata = request.form['mata']
    santaan = request.form['santaan']
    lagna = request.form['lagna']
    janam_nakshatra = request.form['janam_nakshatra']
    charana = request.form['charana']
    janam_namakshar = request.form['janam_namakshar']
    janam_naam = request.form['janam_naam']
    rashi = request.form['rashi']
    swami = request.form['swami']
    varna = request.form['varna']
    vashya = request.form['vashya']
    yoni = request.form['yoni']
    gana = request.form['gana']
    nadi = request.form['nadi']
    paya = request.form['paya']
    
    conn = sqlite3.connect('astrology.db')
    c = conn.cursor()
    c.execute('''
        INSERT INTO astrology_form (
            janam_tithi,
            janam_samay,
            janam_sthan,
            vikrami_samvant,
            shak,
            reetu,
            maas,
            paksha, 
            vaar,
            tithi, 
            nakshatra,
            vansh,
            gotra,
            prapitamah,
            pitamah,
            pita,
            mata,
            santaan,
            lagna,
            janam_nakshatra,
            charana,
            janam_namakshar,
            janam_naam,
            rashi,
            swami,
            varna,
            vashya,
            yoni,
            gana,
            nadi,
            paya)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    ''', (janam_tithi, janam_samay, janam_sthan, vikrami_samvant, shak, reetu, maas, paksha, vaar, tithi, nakshatra, vansh, gotra, prapitamah, pitamah, pita, mata, santaan, lagna, janam_nakshatra, charana, janam_namakshar, janam_naam, rashi, swami, varna, vashya, yoni, gana, nadi, paya ))
    conn.commit()
    conn.close()

    return redirect('/view')

# Route to display stored data
@app.route('/view')
def view_data():
     conn = sqlite3.connect('astrology.db')
     c = conn.cursor()
     c.execute('SELECT * FROM astrology_form')
     data = c.fetchall()
     conn.close()
     return render_template('view.html', data=data)

# Route to delete an entry
@app.route('/delete/<int:id>', methods=['GET'])
def delete_submission(id):
    conn = sqlite3.connect('astrology.db')
    c = conn.cursor()
    c.execute("DELETE FROM astrology_form WHERE id = ?", (id,))
    conn.commit()
    conn.close()
    return redirect('/view')

if __name__ == '__main__':
    app.run(debug=True)

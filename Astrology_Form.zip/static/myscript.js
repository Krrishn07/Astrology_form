
        const tithiOptions = {
            "Shukla Paksha": ["Pratipada", "Dwitiya", "Tritiya", "Chaturthi", "Panchami", "Shashti", "Saptami", "Ashtami", "Navami", "Dashami", "Ekadashi", "Dwadashi", "Trayodashi", "Chaturdashi", "Purnima"],
            "Krishna Paksha": ["Pratipada", "Dwitiya", "Tritiya", "Chaturthi", "Panchami", "Shashti", "Saptami", "Ashtami", "Navami", "Dashami", "Ekadashi", "Dwadashi", "Trayodashi", "Chaturdashi", "Amavasya"]
        };

        function updateTithiOptions() {
            const pakshaSelect = document.getElementById("paksha");
            const tithiSelect = document.getElementById("tithi");
            const selectedPaksha = pakshaSelect.value;

            tithiSelect.innerHTML = '<option value="" disabled selected>Select Tithi</option>';
            if (selectedPaksha && tithiOptions[selectedPaksha]) {
                tithiOptions[selectedPaksha].forEach(tithi => {
                    const option = document.createElement("option");
                    option.value = tithi
                    option.textContent = tithi;
                    tithiSelect.appendChild(option);
                });
            }
        }